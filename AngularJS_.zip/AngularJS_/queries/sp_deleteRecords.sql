Create proc Sp_register_delete

@Sr_no int

as

begin

delete from tbl_registration where Sr_no=@Sr_no

end