Create proc Sp_register

   @Email    NVARCHAR (100) ,

    @Password NVARCHAR (MAX) ,

    @Name     VARCHAR (MAX)  ,

    @Address  NVARCHAR (MAX) ,

    @City     NVARCHAR (MAX)

     as

     begin

     insert into tbl_registration values(@Email,@Password,@Name,@Address,@City)

     end