Create proc Sp_register_get

as

begin

Select * from tbl_registration

End