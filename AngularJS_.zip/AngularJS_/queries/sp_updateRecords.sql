CREATE proc Sp_register_Update

@Sr_no int ,

@Email nvarchar(200),

@Password nvarchar(200),

@Name nvarchar(200),

@Address nvarchar(max),

@City nvarchar(200)

as

begin

update tbl_registration set Email=@Email,Password=@Password,Name=@Name,Address=@Address,City=@City where Sr_no=@Sr_no

end