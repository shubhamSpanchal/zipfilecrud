Create proc Sp_register_byid

@Sr_no int

as

begin

Select * from tbl_registration where Sr_no=@Sr_no

End