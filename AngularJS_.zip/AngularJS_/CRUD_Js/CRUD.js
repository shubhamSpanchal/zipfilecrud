﻿
    var app = angular.module('MyApp', []);
    app.controller('MyController', function ($scope, $http, $window) {
        $scope.ButtonText = "Add";
    GetCustomers($scope);
    $scope.Add = function () {
                var obj = { };
    obj.id = $scope.Id == undefined ? 0 : $scope.Id;
    obj.name = $scope.Name;
    obj.country = $scope.Country;
    $.ajax({
        url: 'https://localhost:44375/contract/CRUD_Contract.aspx/AddUpdateCustomer',
    type: 'POST',
    contentType: 'application/json',
    data: JSON.stringify(obj),
    success: function (response) {
        GetCustomers($scope);
    $scope.Id = "";
    $scope.Name = "";
    $scope.Country = "";
    $scope.ButtonText = "Add";
    window.alert('Record Added')
                    },
    error: function (err) {
        alert(response.responseText);
                    }
                });
            }

    $scope.Delete = function (id) {
                var obj = { };
    obj.id = id;
    $.ajax({
        url: 'https://localhost:44375/contract/CRUD_Contract.aspx/DeleteCustomer',
    type: "POST",
    contentType: 'application/json',
    data: JSON.stringify(obj),
    success: function (response) {
        GetCustomers($scope);
                    },
    error: function (err) {
        alert(response.responseText);
                    }
                });
            }

    $scope.Edit = function (id) {
                var customers = $scope.Customers;
    customers.map(function (customer) {
                    if (customer.Id == id) {
        $scope.Id = customer.Id;
    $scope.Name = customer.Name;
    $scope.Country = customer.Country;
    $scope.ButtonText = "Update";
                    }
                });
            }
        });
    function GetCustomers($scope) {
        $.ajax({
            url: 'https://localhost:44375/contract/CRUD_Contract.aspx/GetCustomers',
            type: "POST",
            contentType: 'application/json',
            success: function (response) {
                $scope.Customers = response.d;
                $scope.$apply();
            },
            error: function (err) {
                alert(response.responseText);
            }
        });
        }